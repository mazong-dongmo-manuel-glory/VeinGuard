import { create } from 'zustand';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as SecureStore from 'expo-secure-store';
import {
  auth,
  FIREBASE_ENABLED,
} from '../services/firebase';
import {
  createUserWithEmailAndPassword,
  onAuthStateChanged,
  signInWithEmailAndPassword,
  signOut,
} from 'firebase/auth';
import { getDefaultPreferences, loadUserPreferences, saveUserPreferences } from '../services/preferences';

const REMEMBER_KEY = 'auth_remember_session';
const EMAIL_KEY = 'auth_email';
const PASSWORD_KEY = 'auth_password';

const normalizeEmail = (value) => String(value || '').trim().toLowerCase();
let authSubscription = null;

export const useAuthStore = create((set, get) => ({
  user: null,
  authReady: false,
  rememberSession: true,
  preferences: getDefaultPreferences(),

  bootstrap: async () => {
    if (!FIREBASE_ENABLED || !auth) {
      set({ authReady: true });
      return;
    }

    const rememberSession = (await AsyncStorage.getItem(REMEMBER_KEY)) !== '0';
    set({ rememberSession, authReady: false });

    if (!auth.currentUser && rememberSession) {
      const email = await SecureStore.getItemAsync(EMAIL_KEY);
      const password = await SecureStore.getItemAsync(PASSWORD_KEY);
      if (email && password) {
        try {
          await signInWithEmailAndPassword(auth, email, password);
        } catch {
          await AsyncStorage.removeItem(REMEMBER_KEY);
          await SecureStore.deleteItemAsync(EMAIL_KEY);
          await SecureStore.deleteItemAsync(PASSWORD_KEY);
        }
      }
    }

    if (!authSubscription) {
      authSubscription = onAuthStateChanged(auth, async (user) => {
        const preferences = user ? await loadUserPreferences(user.uid) : getDefaultPreferences();
        set({
          user,
          authReady: true,
          preferences,
        });
      });
      return;
    }

    const fallbackUser = auth.currentUser;
    const preferences = fallbackUser ? await loadUserPreferences(fallbackUser.uid) : getDefaultPreferences();
    set({
      user: fallbackUser,
      authReady: true,
      preferences,
      rememberSession,
    });
  },

  login: async ({ email, password, rememberSession }) => {
    if (!FIREBASE_ENABLED || !auth) {
      throw new Error('Firebase Authentication is not available.');
    }

    const normalizedEmail = normalizeEmail(email);
    const normalizedPassword = String(password || '');
    const shouldRemember = rememberSession !== false;
    const credential = await signInWithEmailAndPassword(auth, normalizedEmail, normalizedPassword);

    if (shouldRemember) {
      await AsyncStorage.setItem(REMEMBER_KEY, '1');
      await SecureStore.setItemAsync(EMAIL_KEY, normalizedEmail);
      await SecureStore.setItemAsync(PASSWORD_KEY, normalizedPassword);
    } else {
      await AsyncStorage.setItem(REMEMBER_KEY, '0');
      await SecureStore.deleteItemAsync(EMAIL_KEY);
      await SecureStore.deleteItemAsync(PASSWORD_KEY);
    }

    set({
      user: credential.user,
      rememberSession: shouldRemember,
    });
    return credential.user;
  },

  signup: async ({ email, password, rememberSession }) => {
    if (!FIREBASE_ENABLED || !auth) {
      throw new Error('Firebase Authentication is not available.');
    }

    const normalizedEmail = normalizeEmail(email);
    const normalizedPassword = String(password || '');
    const credential = await createUserWithEmailAndPassword(auth, normalizedEmail, normalizedPassword);
    await saveUserPreferences(credential.user.uid, getDefaultPreferences());

    if (rememberSession !== false) {
      await AsyncStorage.setItem(REMEMBER_KEY, '1');
      await SecureStore.setItemAsync(EMAIL_KEY, normalizedEmail);
      await SecureStore.setItemAsync(PASSWORD_KEY, normalizedPassword);
    } else {
      await AsyncStorage.setItem(REMEMBER_KEY, '0');
      await SecureStore.deleteItemAsync(EMAIL_KEY);
      await SecureStore.deleteItemAsync(PASSWORD_KEY);
    }

    set({
      user: credential.user,
      rememberSession: rememberSession !== false,
      preferences: getDefaultPreferences(),
    });
    return credential.user;
  },

  logout: async () => {
    if (auth) {
      await signOut(auth);
    }
    await AsyncStorage.setItem(REMEMBER_KEY, '0');
    await SecureStore.deleteItemAsync(EMAIL_KEY);
    await SecureStore.deleteItemAsync(PASSWORD_KEY);
    set({
      user: null,
      rememberSession: false,
      preferences: getDefaultPreferences(),
    });
  },

  updatePreferences: async (partialPreferences) => {
    const user = get().user;
    if (!user) {
      return get().preferences;
    }

    const nextPreferences = {
      ...get().preferences,
      ...partialPreferences,
    };
    const saved = await saveUserPreferences(user.uid, nextPreferences);
    set({ preferences: saved });
    return saved;
  },
}));
